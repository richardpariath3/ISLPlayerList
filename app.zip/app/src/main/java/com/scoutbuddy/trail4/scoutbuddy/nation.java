package com.scoutbuddy.trail4.scoutbuddy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class nation extends AppCompatActivity {

    public static final String EXTRA_MESSAGE ="com.scoutbuddy.trail4.scoutbuddy.nation";
    public AutoCompleteTextView mnationautotext;
    private TextView mnationtext;
    private Button mlogout,mconfirmbtn;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private static final String[] COUNTRY = new String[] {
            "INDIA", "SPAIN", "BRAZIL"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nation);

        mnationtext=(TextView) findViewById(R.id.nationtext);
        mnationautotext=(AutoCompleteTextView) findViewById(R.id.nationautotext);
        mlogout=(Button) findViewById(R.id.logoutbtn);
        mAuth= FirebaseAuth.getInstance();
        mconfirmbtn=(Button) findViewById(R.id.confirmbtn);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line,COUNTRY);
        mnationautotext.setAdapter(adapter);

        mAuthListener = new FirebaseAuth.AuthStateListener()
        {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth)
            {
                if(firebaseAuth.getCurrentUser()==null)
                {
                    startActivity(new Intent(nation.this,LoginActivity.class));
                }
            }
        };

        mlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
            }
        });
        mconfirmbtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(nation.this,MainActivityNation.class);
                String message=mnationautotext.getText().toString();
                if(TextUtils.isEmpty(message))
                {
                    Intent i = new Intent(nation.this,blanknation.class);
                    startActivity(i);
                }
                else {
                    intent.putExtra(EXTRA_MESSAGE, message);
                    startActivity(intent);
                }
            }

        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }
    }
