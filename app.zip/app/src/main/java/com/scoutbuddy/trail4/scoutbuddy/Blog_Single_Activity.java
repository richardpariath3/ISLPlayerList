package com.scoutbuddy.trail4.scoutbuddy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import static java.lang.System.load;

public class Blog_Single_Activity extends AppCompatActivity {
    private String mPost_key;
    private DatabaseReference mDatabase;
    private ImageView mBlogSingleGraphImage;
   // private TextView mPerformance;
   // private TextView mMarket;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blog__single_);

        mDatabase = FirebaseDatabase.getInstance().getReference().child("Blog");

        mPost_key = getIntent().getExtras().getString("Blog_id");
        mBlogSingleGraphImage=(ImageView) findViewById(R.id.graph);
       // mPerformance=(TextView) findViewById(R.id.performancetext);
       // mMarket=(TextView) findViewById(R.id.markettext);
        mDatabase.child(mPost_key).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String post_image=(String) dataSnapshot.child("stats").getValue();
                String post_performance=(String) dataSnapshot.child("performance").getValue();
                String post_market=(String) dataSnapshot.child("value").getValue();
               // mMarket.setText(post_market);
               // mPerformance.setText(post_performance);
                Picasso.with(Blog_Single_Activity.this).load(post_image).into(mBlogSingleGraphImage);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
}
