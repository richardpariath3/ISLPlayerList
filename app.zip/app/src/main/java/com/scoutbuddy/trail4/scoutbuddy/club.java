package com.scoutbuddy.trail4.scoutbuddy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class club extends AppCompatActivity {

    public static final String EXTRA_MESSAGE1 ="com.scoutbuddy.trail4.scoutbuddy.club";
    private AutoCompleteTextView mclub;
    private TextView mclubtext;
    private Button mlogout;
    private FirebaseAuth mAuth;
    public String club;
    private Button mconfirmbtn;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private static final String[] CLUBS = new String[] {
            "CHENNAIYIN FC", "ATLETICO DE KOLKATA"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club);

        mclubtext=(TextView) findViewById(R.id.clubtext);
        mclub=(AutoCompleteTextView) findViewById(R.id.clubautotext);
        mlogout=(Button) findViewById(R.id.logoutbtn);
        mconfirmbtn=(Button) findViewById(R.id.confirmbtn);
        mAuth=FirebaseAuth.getInstance();


        mconfirmbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(club.this,MainClubActivityClub.class);
                String message=mclub.getText().toString();
                if(TextUtils.isEmpty(message)) {
                    Intent i = new Intent(club.this, blanknation.class);
                    startActivity(i);
                }
                else
                {
                    intent1.putExtra(EXTRA_MESSAGE1, message);
                    startActivity(intent1);
                }
            }
        });
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line,CLUBS);
        AutoCompleteTextView textView = (AutoCompleteTextView)
                findViewById(R.id.clubautotext);
        textView.setAdapter(adapter);

        mAuthListener = new FirebaseAuth.AuthStateListener()
        {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth)
            {
                if(firebaseAuth.getCurrentUser()==null)
                {
                    startActivity(new Intent(club.this,LoginActivity.class));
                }
            }
        };


        mlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
            }
        });

        club=mclub.getText().toString();

    }

    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    public String toString()
    {
        return club;
    }
    }

