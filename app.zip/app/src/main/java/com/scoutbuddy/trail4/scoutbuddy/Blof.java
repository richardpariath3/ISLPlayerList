package com.scoutbuddy.trail4.scoutbuddy;

import android.widget.ImageView;

/**
 * Created by dell on 3/11/2017.
 */

public class Blof
{
    private String title,desc,image,title1,title2,title3,title4;

    public Blof()
    {

    }

    public Blof(String title, String desc, String image, String title1,String title2, String title3, String title4) {
        this.title = title;
        this.desc = desc;
        this.image = image;
        this.title1=title1;
        this.title2=title2;
        this.title3=title3;
        this.title4=title4;
    }

    public String getTitle1() {
        return title1;
    }

    public void setTitle1(String title1) {
        this.title1 = title1;
    }



    public String getTitle2() {
        return title2;
    }

    public void setTitle2(String title2) {
        this.title2 = title2;
    }

    public String getTitle3() {
        return title3;
    }

    public void setTitle3(String title3) {
        this.title3 = title3;
    }

    public String getTitle4() {
        return title4;
    }

    public void setTitle4(String title4) {
        this.title4 = title4;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {

        this.image = image;
    }
}
