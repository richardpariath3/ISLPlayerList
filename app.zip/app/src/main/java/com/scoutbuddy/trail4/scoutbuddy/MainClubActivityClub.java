
package com.scoutbuddy.trail4.scoutbuddy;

        import android.content.Context;
        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.support.v7.widget.LinearLayoutManager;
        import android.support.v7.widget.RecyclerView;
        import android.view.View;
        import android.widget.ImageButton;
        import android.widget.ImageView;
        import android.widget.TextView;

        import com.firebase.client.Firebase;
        import com.firebase.ui.database.FirebaseRecyclerAdapter;
        import com.google.firebase.auth.FirebaseAuth;
        import com.google.firebase.database.ChildEventListener;
        import com.google.firebase.database.DataSnapshot;
        import com.google.firebase.database.DatabaseError;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.google.firebase.database.Query;
        import com.google.firebase.database.ValueEventListener;
        import com.squareup.picasso.Picasso;

public class MainClubActivityClub extends AppCompatActivity {

    private RecyclerView mBlogList;
    private DatabaseReference mDatabase;
    private Query mData;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabaseLike;
    private boolean mProcessLike = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_club);
        mAuth=FirebaseAuth.getInstance();

        Intent intent = getIntent();

        mDatabase = FirebaseDatabase.getInstance().getReference().child("Blog");
        String message = intent.getStringExtra(club.EXTRA_MESSAGE1);
        mData = mDatabase.orderByChild("title2").equalTo(message);
        mDatabaseLike=FirebaseDatabase.getInstance().getReference().child("Likes");

        mDatabaseLike.keepSynced(true);
        mDatabase.keepSynced(true);

        /*
        Intent intent1 = getIntent();
        if(intent1!=null) {

            mDatabase = FirebaseDatabase.getInstance().getReference().child("Blog");
            String message1 = intent1.getStringExtra(club.EXTRA_MESSAGE1);
            mData = mDatabase.orderByChild("title2").equalTo(message1);
        }
        Intent intent2 = getIntent();
        Intent intent3 = getIntent();

        if(intent2!=null && intent3!=null)
        {

            mDatabase = FirebaseDatabase.getInstance().getReference().child("Blog");
             String message2 = intent2.getStringExtra(age.EXTRA_MESSAGE2);
             String message3 = intent3.getStringExtra(age.EXTRA_MESSAGE3);
             mData = mDatabase.orderByChild("title4").startAt(message2).endAt(intent3.getStringExtra(message3));
        }
        */

        // mDatabaseFav = FirebaseDatabase.getInstance().getReference().child("Favourites");


        //

        mBlogList = (RecyclerView) findViewById(R.id.blog_list);
        mBlogList.setHasFixedSize(true);
        mBlogList.setLayoutManager(new LinearLayoutManager(this));

    }

    @Override
    protected void onStart() {
        super.onStart();
        Query query = mDatabase.child("Blog").orderByChild("title2").equalTo("ATLETICO DE KOLKATA");
        query.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {


            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        FirebaseRecyclerAdapter<Blof, BlogViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Blof, BlogViewHolder>(
                Blof.class,
                R.layout.blog_row,
                BlogViewHolder.class,
                mData
        ) {
            @Override
            protected void populateViewHolder(BlogViewHolder viewHolder, Blof model, final int position) {
                final String post_key = getRef(position).getKey();

                viewHolder.setTitle(model.getTitle());
                viewHolder.setDesc(model.getDesc());
                viewHolder.setTitle1(model.getTitle1());
                viewHolder.setTitle2(model.getTitle2());
                viewHolder.setTitle3(model.getTitle3());
                viewHolder.setTitle4(model.getTitle4());
                viewHolder.setImage(getApplicationContext(),model.getImage());
                // viewHolder.setImage(getApplicationContext(),model.getImage());

                viewHolder.setLikebtn(post_key);

                viewHolder.mTrendbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent singleBlogIntent = new Intent(MainClubActivityClub.this,Blog_Single_Activity.class);
                        singleBlogIntent.putExtra("Blog_id",post_key);
                        startActivity(singleBlogIntent);

                    }
                });
                // viewHolder.setImage(getApplicationContext(),model.getImage());

                viewHolder.mLikebtn.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        mProcessLike= true;


                        {
                            mDatabaseLike.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    if (mProcessLike)
                                    {
                                        if (dataSnapshot.child(post_key).hasChild(mAuth.getCurrentUser().getUid())) {
                                            mDatabaseLike.child(post_key).child(mAuth.getCurrentUser().getUid()).removeValue();
                                            mProcessLike = false;
                                        } else {
                                            mDatabaseLike.child(post_key).child(mAuth.getCurrentUser().getUid()).setValue("RandomValue");
                                            mProcessLike = false;
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {

                                }
                            });
                        }
                    }

                });

            }
        };



        mBlogList.setAdapter(firebaseRecyclerAdapter);
    }

    public static class BlogViewHolder extends RecyclerView.ViewHolder {
        View mView;
        ImageButton mLikebtn;
        ImageButton mTrendbtn;
        DatabaseReference mDatabaseLike;
        FirebaseAuth mAuth;


        public BlogViewHolder(View itemView) {
            super(itemView);

            mView = itemView;
            mTrendbtn=(ImageButton)mView.findViewById(R.id.trend_btn);
            mLikebtn=(ImageButton)mView.findViewById(R.id.like_btn);
            mDatabaseLike=FirebaseDatabase.getInstance().getReference().child("Likes");
            mAuth=FirebaseAuth.getInstance();
            mDatabaseLike.keepSynced(true);

        }

        public void setLikebtn(final String post_key)
        {
            mDatabaseLike.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if(dataSnapshot.child(post_key).hasChild(mAuth.getCurrentUser().getUid()))
                    {
                        mLikebtn.setImageResource(R.mipmap.ic_favorite_black_24dp);
                    }
                    else
                    {
                        mLikebtn.setImageResource(R.mipmap.ic_favorite_border_black_24dp);
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }

        public void setTitle(String title) {
            TextView post_title = (TextView) mView.findViewById(R.id.posttext);
            post_title.setText(title);
        }

        public void setDesc(String desc) {
            TextView post_desc = (TextView) mView.findViewById(R.id.postdesc);
            post_desc.setText(desc);
        }

        public void setTitle1(String title1) {
            TextView post_title1 = (TextView) mView.findViewById(R.id.posttext1);
            post_title1.setText(title1);
        }

        public void setTitle2(String title2) {
            TextView post_title2 = (TextView) mView.findViewById(R.id.posttext2);
            post_title2.setText(title2);
        }

        public void setTitle3(String title3) {
            TextView post_title3 = (TextView) mView.findViewById(R.id.posttext3);
            post_title3.setText(title3);
        }

        public void setTitle4(String title4) {
            TextView post_title4 = (TextView) mView.findViewById(R.id.posttext4);
            post_title4.setText(title4);
        }

        public void setImage(Context ctx, String image)
        {
            ImageView post_image=(ImageView) mView.findViewById(R.id.image_player);
            Picasso.with(ctx).load(image).into(post_image);
        }


    }
}

