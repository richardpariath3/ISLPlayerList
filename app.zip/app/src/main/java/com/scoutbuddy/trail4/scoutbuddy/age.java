package com.scoutbuddy.trail4.scoutbuddy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class age extends AppCompatActivity {

    public static final String EXTRA_MESSAGE3 ="com.scoutbuddy.trail4.scoutbuddy.age";
    public static final String EXTRA_MESSAGE2 ="com.scoutbuddy.trail4.scoutbuddy.age";
    private TextView magetext;
    public EditText mmaxage,mminage;
    private Button mlogout;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private Button mconfirmbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age);

        magetext=(TextView) findViewById(R.id.agetext);
        mmaxage=(EditText) findViewById(R.id.maxage);
       // mminage=(EditText) findViewById(R.id.minage);
        mlogout=(Button) findViewById(R.id.logoutbtn);
        mconfirmbtn=(Button) findViewById(R.id.confirmbtn);
        mAuth=FirebaseAuth.getInstance();

        mconfirmbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                /*
                Intent intent1=new Intent(age.this,MainAgeActivityAge.class);
                Intent intent2=new Intent(age.this,MainAgeActivityAge.class);
                String message3=mmaxage.getText().toString();
                String message2=mminage.getText().toString();
                intent1.putExtra(EXTRA_MESSAGE2,message2);
                intent1.putExtra(EXTRA_MESSAGE3,message3);
                startActivity(intent1);
                */

                /*
                Intent intent = new Intent(age.this,MainAgeActivityAge.class);
                Bundle extras = new Bundle();
                String message3=mmaxage.getText().toString();
                String message2=mminage.getText().toString();
                extras.putString("EXTRA_MESSAGE1",message3);
                extras.putString("EXTRA_MESSAGE2",message2);
                intent.putExtras(extras);
                startActivity(intent);
                */

                /*
                Intent intent = new Intent(age.this,MainAgeActivityAge.class);
                intent.putExtra(EXTRA_MESSAGE2, new String[] {"mmaxage","mminage"});
                startActivity(intent);
                */

                Intent intent = new Intent(age.this,MainAgeActivityAge.class);
               // Bundle extras = new Bundle();
                String message3=mmaxage.getText().toString();
                //String message2=mminage.getText().toString();
              //  intent.putExtra(EXTRA_MESSAGE2,message2);
                if(TextUtils.isEmpty(message3))
                {
                    Intent i = new Intent(age.this,blanknation.class);
                    startActivity(i);
                }
                else
                {
                    intent.putExtra(EXTRA_MESSAGE3, message3);
                    // intent.putExtras(extras);
                    startActivity(intent);
                }

            }
        });

        mAuthListener = new FirebaseAuth.AuthStateListener()
        {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth)
            {
                if(firebaseAuth.getCurrentUser()==null)
                {
                    startActivity(new Intent(age.this,LoginActivity.class));
                }
            }
        };

        mlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }
    }

